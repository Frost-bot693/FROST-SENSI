# Frost Sensi — Android App

Ye ek ready Android Studio project hai jisme tumhara "FROST SENSI" logo already
app icon aur in-app branding ke roop mein laga hua hai. App poori tarah
offline chalti hai (Free Fire Max sensitivity generator) — koi permission
nahi maangti.

## Build kaise karein (APK/AAB banane ke liye)

1. **Android Studio** install karo (free): https://developer.android.com/studio
2. Android Studio kholo → **Open** → ye poora `FrostSensi` folder select karo.
3. Pehli baar Gradle sync hone do (internet chahiye, Android Studio khud
   sab kuch download kar lega — koi manual setup nahi).
4. Test karne ke liye: **Run ▶** button dabao (emulator ya apne phone pe USB
   debugging se).
5. Play Store ke liye release build banane ke liye:
   - Top menu → **Build → Generate Signed Bundle / APK**
   - **Android App Bundle (.aab)** choose karo (Play Store ke liye yehi required hai)
   - Naya keystore banao (ek password set karke) — **isko safe rakho**,
     future updates isi keystore se sign karne padenge.
   - Build ho jaane ke baad `.aab` file `app/release/` folder mein milegi.

## Play Store pe daalne ke liye kya chahiye

1. Google Play Console account (one-time $25 fee): https://play.google.com/console
2. Store listing ke liye:
   - App name: Frost Sensi
   - Short + full description
   - Screenshots (app chalakar screenshot le lo)
   - App icon 512x512 → `play_store_icon_512.png` (isi folder ke bahar diya hua hai)
   - Feature graphic 1024x500 (banana padega, app icon se alag hota hai)
3. **Privacy Policy URL** — Play Store isko mandatory bana chuka hai, chahe
   app kitna bhi simple ho. Ek simple page bana lo (Google Sites free hai)
   jisme likh do: "Frost Sensi kisi bhi personal data ko collect, store ya
   share nahi karta. Sab kuch device pe hi offline chalta hai."
4. Content rating questionnaire fill karo (simple utility app, low risk).
5. Submit karo — Google ka review usually 1-3 din leta hai.

## Naya OB update aane par

`app/src/main/assets/www/index.html` file kholo, `OB_UPDATES` array dhundo
(script ke top mein), naya entry add karo jaise:

```js
{ id: "OB56", label: "OB56" }
```

Phir dobara build karke Play Store pe update (naya versionCode ke saath,
`app/build.gradle` mein `versionCode` +1 badha do) push kar do.

## Project structure

- `app/src/main/assets/www/index.html` — pura sensitivity generator (HTML/CSS/JS)
- `app/src/main/assets/www/logo.png` — tumhara logo, app ke andar header mein
- `app/src/main/res/mipmap-*` — app icon (saare density sizes already generate ho chuke hain)
- `app/src/main/java/.../MainActivity.kt` — bas ek WebView jo upar wali HTML file load karta hai
